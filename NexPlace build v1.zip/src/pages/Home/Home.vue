<template>
    <div id="top" class="page">
        <Intro />
        <KeyBenefits />
        <Welcome />
        <GetOurApp />
        <OurProducts />
        <RealTimeStats />
        <Partners />
        <Faq />
    </div>
</template>

<script setup>
import Intro from "./Sections/Intro/Intro.vue";
import KeyBenefits from "./Sections/KeyBenefits/KeyBenefits.vue";
import Welcome from "./Sections/Welcome/Welcome.vue";
import GetOurApp from "./Sections/GetOurApp/GetOurApp.vue";
import OurProducts from "./Sections/OurProducts/OurProducts.vue";
import RealTimeStats from "./Sections/RealTimeStats/RealTimeStats.vue";
import Partners from "./Sections/Partners/Partners.vue";
import Faq from "./Sections/Faq/Faq.vue";
import Footer from "../../components/Footer/Footer.vue";
</script>

<style scoped></style>
